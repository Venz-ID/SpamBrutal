pkg upgrade
pkg update
pip install --upgrade pip
pip2 install --upgrade pip
pip  install mechanize
pip2 install mechanize
pip2 install requests
pip install requests
pkg install python
pkg install python2


